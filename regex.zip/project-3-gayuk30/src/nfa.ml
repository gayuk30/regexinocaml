open List
open Sets

(*********)
(* Types *)
(*********)

type ('q, 's) transition = 'q * 's option * 'q

type ('q, 's) nfa_t = {
  sigma: 's list; (* list of alphabet*)
  qs: 'q list; (* list of states like 0, 1, etc*)  (* [1;2;3;4] *)
  q0: 'q; (* initial state *)
  fs: 'q list; (* final states*)
  delta: ('q, 's) transition list; (* list of tuples (1, "a", 2) *)
}

(***********)
(* Utility *)
(***********)

(* explode converts a string to a character list *)
let explode (s: string) : char list =
  let rec exp i l =
    if i < 0 then l else exp (i - 1) (s.[i] :: l)
  in
  exp (String.length s - 1) []

(****************)
(* Part 1: NFAs *)
(****************)


(* MOVE STARTS *)
(* List.mem a b: if a is in list b *)
let move (nfa: ('q,'s) nfa_t) (qs: 'q list) (s: 's option) : 'q list =
  fold_left (fun acc tup -> match tup with 
  | (a,b,c) -> if (b = s && List.mem a qs) && ((List.mem c acc) != true) then c::acc else acc) [] nfa.delta;;


let rec e_helper nfa qs a = 
  match qs with 
  | [] -> a
  | q::rest -> let qs = (move nfa qs None) in e_helper nfa (diff qs a) (insert_all qs a);;

let e_closure (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list =
  let states = (move nfa qs None) in union qs (e_helper nfa states states);;

let accept (nfa: ('q,char) nfa_t) (s: string) : bool =
  let rec accept_helper states input = 
    match input with 
    | [] -> if (intersection (e_closure nfa states) nfa.fs) = [] then false else true
    | h::t -> accept_helper ( move nfa (e_closure nfa states) ( Some h)) t in accept_helper ([nfa.q0]) (explode s);;


(*******************************)
(* Part 2: Subset Construction *)
(*******************************)
(* union *)
let new_states (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list list =
  fold_left (fun acc a -> union [e_closure nfa (move nfa qs (Some a))] acc) [] nfa.sigma;;

  
let new_trans (nfa: ('q,'s) nfa_t) (qs: 'q list) : ('q list, 's) transition list =
  fold_left (fun acc a -> union [(qs, Some a, e_closure nfa (move nfa qs (Some a)))] acc) [] nfa.sigma;;

  
let new_finals (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list list =
  let rec rec_helper lst = 
    match lst with 
    | [] -> false
    | h::t -> if (elem h qs) = true then true else rec_helper t in if rec_helper nfa.fs then [qs] else [];;

(* recheck logic:  *)

let rec nfa_to_dfa_step nfa dfa unstates =
  match unstates with
  | [] -> (let final_qs = (fold_left ( fun a x -> a @ (new_finals nfa x)) [] dfa.qs) in {sigma = dfa.sigma; qs = dfa.qs; q0 = dfa.q0; fs = final_qs; delta = dfa.delta})
  | q::rest -> (let new_qs = (new_states nfa q) in 
  
  let sec_unstates = if(subset new_qs dfa.qs) then rest else (union new_qs rest) in nfa_to_dfa_step nfa
    {sigma = dfa.sigma;
    qs = (union dfa.qs sec_unstates);
    q0 = dfa.q0;
    fs = dfa.fs;
    delta = (union dfa.delta(new_trans nfa q))} sec_unstates);;

(* eclosue on start state. Rest: move and e-closure*)
let nfa_to_dfa (nfa: ('q,'s) nfa_t) : ('q list, 's) nfa_t =
  let updateqs = (e_closure nfa[nfa.q0]) in nfa_to_dfa_step nfa 
  {sigma = nfa.sigma; qs = [updateqs]; q0 = updateqs; fs = (new_finals nfa updateqs); delta = []}[updateqs];; 