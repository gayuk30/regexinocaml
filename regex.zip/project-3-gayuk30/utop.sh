#! /bin/sh
dune utop src
