#! /bin/sh
dune exec bin/viz.bc
