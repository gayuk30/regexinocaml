#! /bin/sh
dune runtest -f
